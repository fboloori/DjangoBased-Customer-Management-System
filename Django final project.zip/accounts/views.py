from django.contrib.auth import authenticate, login , logout
from django.contrib.auth.decorators import login_required
from django.db.models import Q
from rest_framework import status
from rest_framework.decorators import api_view , authentication_classes
from accounts.CsrfExemptSessionAuthentication import *

from rest_framework.response import Response

from accounts.serializers import *


##########################################################################################################################################
@api_view(["POST","GET","PUT","DELETE","PATCH","COPY","HEAD","OPTION","LINK","UNLINK","LOCK","UNLOCK","VIEW","PROFIND","PURGE"])
def customerRegister(request):
    if request.method != 'POST':
        return Response({"message":"A POST request expected"}, status=status.HTTP_400_BAD_REQUEST)
    dictData=dict(request.data)
    dictData={"user": dict([(key,value) for (key,value) in dictData.items()
                          if key in ['username','password',"first_name","last_name","email"]]),
               "phone":dictData['phone'],
               "address": dictData['address']
               }
    new = CustomerSerializer(data=dictData)
    if not new.is_valid():
        return Response(new.errors, status=status.HTTP_400_BAD_REQUEST)
    new.save()
    return Response({"id":new.data['id']}, status=status.HTTP_201_CREATED)


##########################################################################################################################################
@api_view(["POST","GET","PUT","DELETE","PATCH","COPY","HEAD","OPTION","LINK","UNLINK","LOCK","UNLOCK","VIEW","PROFIND","PURGE"])
@authentication_classes([CsrfExemptSessionAuthentication])
def customerList(request):
    if request.method != 'GET':
        return Response({"message":"A GET request expected"},status=status.HTTP_400_BAD_REQUEST)
    if not request.GET:
        return Response({"results":[x.dictionary() for x in Customer.objects.all()]},
                        status=status.HTTP_200_OK)
    #if  request.GET:
    search_text=request.GET['search']
    q=Q(phone__contains=search_text)\
      |Q(address__contains=search_text)\
      |Q(user__first_name__contains=search_text) \
      |Q(user__last_name__contains=search_text)\
      |Q(user__username__contains=search_text)\
      |Q(user__email__contains=search_text)
    selected=Customer.objects.filter(q)
    result = [x.dictionary() for x in selected]
    return Response({"customers":result}, status=status.HTTP_200_OK)


##########################################################################################################################################
@api_view(["POST","GET","PUT","DELETE","PATCH","COPY","HEAD","OPTION","LINK","UNLINK","LOCK","UNLOCK","VIEW","PROFIND","PURGE"])
@authentication_classes([CsrfExemptSessionAuthentication])
def customerDetail(request,pk):
    if request.method != 'GET':
        return Response({"message":"A GET request expected"},status=status.HTTP_400_BAD_REQUEST)
    try:
        customer=Customer.objects.get(pk=pk)
        return Response(customer.dictionary(),status=status.HTTP_200_OK)
    except:
        return Response({"message": "Customer Not Found."}, status=status.HTTP_404_NOT_FOUND)

##########################################################################################################################################
@api_view(["POST","GET","PUT","DELETE","PATCH","COPY","HEAD","OPTION","LINK","UNLINK","LOCK","UNLOCK","VIEW","PROFIND","PURGE"])
@authentication_classes([CsrfExemptSessionAuthentication])
def customerEdit(request,pk):
    if request.method != 'POST' and request.method != 'PATCH':
        return Response({"message":"A POST request expected"},status=status.HTTP_400_BAD_REQUEST)
    try:
        customer = Customer.objects.get(pk=pk)
    except:
        return Response({"message": "customer does not exist"}, status=status.HTTP_404_NOT_FOUND)

    data = dict(request.data)

    if 'username' in data.keys() or 'id' in data.keys() or 'password' in data.keys():
        return Response({"message": "Cannot edit customer's identity and credentials"}, status=status.HTTP_403_FORBIDDEN)

    dictData = {'user':{}}
    for (key, value) in data.items():
        if key in [ "first_name", "last_name", "email"]:
            dictData['user'][key]=value
        else:
            dictData[key]=value

    customer=CustomerSerializer(instance=customer,data=dictData,partial=True)
    if customer.is_valid():
        customer=customer.save()
        return Response(customer.dictionary(), status=status.HTTP_200_OK)
    else:
        return Response(customer.errors, status=status.HTTP_400_BAD_REQUEST)





##########################################################################################################################################

@api_view(["POST","GET","PUT","DELETE","PATCH","COPY","HEAD","OPTION","LINK","UNLINK","LOCK","UNLOCK","VIEW","PROFIND","PURGE"])
def customerLogin(request):
    if request.method == 'POST':
            recieved_data=dict(request.data)
            username=recieved_data.get('username','')
            password=recieved_data.get('password','')
            auth_user=authenticate(request,username=username,password=password)
            if auth_user is not None:
                login(request,auth_user)
                return Response({"message": "You are logged in successfully."}, status=status.HTTP_200_OK)
            else:
                return Response({"message": "Username or Password is incorrect."}, status=status.HTTP_404_NOT_FOUND)
    else:
        if request.user.is_authenticated:
            return Response({"message": "{} is logged in currently.".format(request.user.username)})
        else:
            return Response({"message": "You should log in first."})






##########################################################################################################################################
@api_view(["POST","GET"])
@authentication_classes([CsrfExemptSessionAuthentication])
def customerLogout(request):

    if request.method == 'POST':
        if request.user.is_authenticated:
            logout(request)
            return Response( {"message": "You are logged out successfully."},status=status.HTTP_200_OK)

        else:
            return Response({"message":"You are not logged in."}, status=status.HTTP_403_FORBIDDEN)
    else:
        return Response({"message": "A POST request expected"}, status=status.HTTP_400_BAD_REQUEST)

##########################################################################################################################################
@api_view(["POST","GET","PUT","DELETE","PATCH","COPY","HEAD","OPTION","LINK","UNLINK","LOCK","UNLOCK","VIEW","PROFIND","PURGE"])
def customerProfile(request):
     if request.user.is_authenticated:
            if request.method!= 'GET':
                return Response({"message": "A GET request expected"}, status=status.HTTP_400_BAD_REQUEST)
            if not request.user.is_authenticated:
                return Response({"message": "You are not logged in yet."}, status=status.HTTP_403_FORBIDDEN)
            user_id=request.user.id
            customer=Customer.objects.get(user_id=user_id)
            return Response(customer.dictionary(), status=status.HTTP_200_OK)
     else:
         return Response({"message":" You are not logged in."}, status=status.HTTP_403_FORBIDDEN)



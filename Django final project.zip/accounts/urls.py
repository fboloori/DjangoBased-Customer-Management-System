from django.urls import path
from django.views.decorators.csrf import csrf_exempt

from accounts import views

urlpatterns = [
    path('customer/register/', views.customerRegister, name='customerRegister'),
    path('customer/list/', views.customerList, name='customerList'),
    path('customer/<int:pk>/', views.customerDetail, name='customerDetail'),
    path('customer/<int:pk>/edit/', views.customerEdit, name='customerEdit'),
    path('customer/login/', views.customerLogin, name='customerLogin'),
    path('customer/logout/', csrf_exempt(views.customerLogout), name='customerLogout'),
    path('customer/profile/', views.customerProfile, name='customerProfile'),
]

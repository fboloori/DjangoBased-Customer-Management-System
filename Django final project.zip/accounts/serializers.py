from django.contrib.auth.models import User
from rest_framework import serializers
from market.models import *


class UserSerializer(serializers.ModelSerializer):
    password=serializers.CharField( write_only=True)
    class Meta:
        model = User
        fields = ['id','username', 'first_name', 'last_name', 'email' ,  'password']

    def create(self, validated_data):
        user = super().create(validated_data)
        user.set_password(validated_data['password'])
        user.is_staff=True
        user.save()
        return (user)

    def update(self, instance, validated_data , partial=True):
        instance.first_name = validated_data.get('first_name', instance.first_name)
        instance.last_name = validated_data.get('last_name', instance.last_name)
        instance.email = validated_data.get('email', instance.email)
        return instance





#######################################################################################################################
class CustomerSerializer(serializers.ModelSerializer):
    user= UserSerializer()
    class Meta:
        model = Customer
        fields = "__all__"

    def create(self, validated_data):
        user_data=validated_data.pop('user')
        ser_user = UserSerializer(data=user_data)
        if not ser_user.is_valid():
            return (ser_user.errors)
        user = ser_user.save()
        try:
            customer=Customer.objects.create(user=user, **validated_data )
        except Exception :
            User.objects.filter(id=user.id).delete()
            raise(Exception)
        return(customer)

    def update(self, instance, validated_data , partial=True):
        instance.address = validated_data.get('address', instance.address)
        instance.phone = validated_data.get('phone', instance.phone)
        instance.balance = validated_data.get('balance', instance.balance)
        if validated_data['user']!={}:
            user_data = validated_data.pop('user')
            updtUser = UserSerializer(instance=instance.user, data=user_data , partial=True)
            if updtUser.is_valid():
                instance.user = updtUser.save()
        instance.save()
        return (instance)


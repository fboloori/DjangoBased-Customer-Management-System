from django.contrib.auth.models import User
from django.core.exceptions import ObjectDoesNotExist
from django.db import models
from datetime import datetime


class Product(models.Model):
    code = models.CharField(max_length=10 , unique=True)
    name = models.CharField(max_length=100)
    price = models.PositiveIntegerField(default=0)
    inventory = models.PositiveIntegerField(default=0)



    def increase_inventory(self, amount):
        if amount<0 :
            raise Exception ('Please give positive amount.')
        self.inventory+=amount
        self.save()
        #return (True)

    def decrease_inventory(self, amount):
        if amount < 0:
            raise Exception('Please give positive amount.')
        if amount > self.inventory:
            raise Exception('Not enough inventory.')
        self.inventory -= amount
        self.save()


class Customer(models.Model):
    user = models.OneToOneField(User,on_delete=models.CASCADE )
    phone = models.CharField("تلفن همراه",max_length=20)
    address = models.TextField("آدرس", null=True , blank=True)
    balance = models.PositiveIntegerField("اعتبار" , default=20000)

    def dictionary(self):
        dic={"id": self.id,
             "username":self.user.username,
             "first_name":self.user.first_name,
             "last_name":self.user.last_name,
             "email":self.user.email,
             "phone":self.phone,
             "address":self.address,
             "balance":self.balance}
        return dic

    def deposit(self, amount):
        if amount < 0:
            raise Exception('Please give positive amount.')
        self.balance+=amount
        self.save()
        return (True)

    def spend(self, amount):
        if amount < 0:
            raise Exception('Please give positive amount.')
        if self.balance<amount:
            raise Exception('Your credit is {}# and less than {} $.'.format(self.balance , amount))
        self.balance-=amount
        self.save()
        return(True)


class OrderRow(models.Model):
    product = models.ForeignKey('Product', on_delete=models.PROTECT)
    order = models.ForeignKey('Order', on_delete=models.PROTECT )
    amount = models.PositiveIntegerField()


class Order(models.Model):
    # Status values. DO NOT EDIT
    STATUS_SHOPPING = 1
    STATUS_SUBMITTED = 2
    STATUS_CANCELED = 3
    STATUS_SENT = 4
    statusChoices=(
        (STATUS_SHOPPING,'در حال خرید'),
        (STATUS_SUBMITTED, 'ثبت شده'),
        (STATUS_CANCELED , 'لغو شده'),
        (STATUS_SENT, 'ارسال شده'),
         )
    customer = models.ForeignKey('Customer',on_delete=models.PROTECT)
    order_time = models.DateTimeField(auto_now=True)
    total_price = models.PositiveIntegerField(default=0)
    status = models.IntegerField(choices=statusChoices, default= STATUS_SHOPPING)
    rows= models.ManyToManyField(OrderRow, related_name='inCart')

    @staticmethod
    def initiate(customer):
            custOrds= Order.objects.filter(customer=customer.id)
            for o in custOrds:
                if o.status==Order.STATUS_SHOPPING:
                    raise Exception ('An Order is currently open.')
            openOrder=Order(customer=customer)
            openOrder.save()
            return(openOrder)

    def add_product(self, product, amount):
            if self.status!=self.STATUS_SHOPPING:
                raise Exception('This order is not open.Please start a new order.')
            if amount<=0 or amount > product.inventory:
                raise Exception('the {} requested item(s) is (are) not available'.format(amount))
            try:
                #the product is in cart
                prodInCart = self.orderrow_set.get(product=product)
                if prodInCart.amount+amount <=product.inventory :
                    prodInCart.amount+=amount
                    prodInCart.save()
                else:
                    raise Exception('You totally requested {} item(s) of this product while only {} item(s) is (are) available'.format(prodInCart.amount+amount , product.inventory))
            except ObjectDoesNotExist:
                # the product is not in cart
                new = OrderRow(product=product, amount=amount, order=self)
                new.save()
            self.total_price+=amount*product.price
            self.save()




    def remove_product(self, product, amount=None):
            if self.status!=self.STATUS_SHOPPING:
                raise Exception('There is not any open order.')
            try:
                prodInCart = self.orderrow_set.get(product=product)
            except :
                raise Exception('this product is not in the cart')
            if not amount: amount=prodInCart.amount
            if amount > prodInCart.amount:
                raise Exception('There is less than {} items of {} in your cart'.format(amount, product.name))
            if amount == None or prodInCart.amount == amount:
                prodInCart.delete()
            else:
                prodInCart.amount-=amount
                prodInCart.save()
            self.total_price -= amount * product.price
            self.save()
            #return (True)

    def submit(self):
            if self.status != self.STATUS_SHOPPING:
                raise Exception('This order is not open.')
            prodInCart = self.orderrow_set.all()
            enough_inventory=True
            for i in prodInCart:
                if (i.product.inventory< i.amount):
                    enough_inventory=False
                    break
            if not enough_inventory:
                raise Exception('There is only {} item(s) of {} in your submission time.'.format(i.product.inventory,i.product.name))
            if  not self.customer.spend(self.total_price):
                raise Exception('Your credit is not enough.')
            for i in prodInCart:
                    i.product.decrease_inventory(i.amount)
            self.status = self.STATUS_SUBMITTED
            self.order_time=datetime.now
            self.save()


    def cancel(self):
        if self.status==self.STATUS_SENT:
            raise Exception('This order has been sent and cannot be canceled.')
        if self.status==self.STATUS_SUBMITTED:
            self.customer.deposit(self.total_price)
            prodInCart=self.orderrow_set.all()
            for i in prodInCart:
                i.product.increase_inventory(i.amount)
                #i.delete()
            #self.delete()
            self.status=self.STATUS_CANCELED
            self.save()
            #return(True)
        else:
            raise Exception('This order cannot be canceled.')

    def send(self):
        if self.status == self.STATUS_SUBMITTED:
            self.status=self.STATUS_SENT
            self.save()
            #return(True)
        else:
            raise Exception('This order cannot be send.')

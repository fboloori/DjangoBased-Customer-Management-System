from rest_framework import serializers
from market.models import  *

class ProductSerializer(serializers.ModelSerializer):
    class Meta:
        model=Product
        fields="__all__"



class CustomerSerializer(serializers.ModelSerializer):
    class Meta:
        model = Customer
        fields = "__all__"



class OrderSerializer(serializers.ModelSerializer):
    customer = CustomerSerializer()
    class Meta:
        model = Order
        fields = "__all__"

class OrderRowSerializer(serializers.ModelSerializer):
    product=ProductSerializer()
    order=OrderSerializer()
    class Meta:
        model = OrderRow
        fields = "__all__"




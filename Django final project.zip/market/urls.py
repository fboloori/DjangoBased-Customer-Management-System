from django.urls import path

from market import views

urlpatterns = [
    path('product/insert/', views.product_insert, name='product_insert'),
    path('product/list/', views.product_list, name='product_list'),
    path('product/<int:pk>/', views.product_detail, name='product_detail'),
    path('product/<int:pk>/edit_inventory/', views.editProductInventory, name='editProductInventory'),
    path('shopping/cart/', views.shoppingCart, name='shoppingCart'),
    path('shopping/cart/add_items/', views.add_items, name='add_items'),
    path('shopping/cart/remove_items/', views.remove_items, name='remove_items'),
    path('shopping/submit/', views.submit, name='submit'),
]

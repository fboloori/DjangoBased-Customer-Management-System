
from accounts.CsrfExemptSessionAuthentication import CsrfExemptSessionAuthentication
from .models import *
from rest_framework import status
from rest_framework.response import Response
from rest_framework.decorators import api_view, authentication_classes
from market.serializers import *

@api_view(["POST","GET","PUT","DELETE","PATCH","COPY","HEAD","OPTION","LINK","UNLINK","LOCK","UNLOCK","VIEW","PROFIND","PURGE"])
def product_insert(request):
    if request.method != 'POST':
        return Response({"message":"A POST request expected"},status=status.HTTP_400_BAD_REQUEST)
    new = ProductSerializer(data=request.data)
    if new.is_valid():
        new.save()
        return Response({"id":new.data["id"]}, status=status.HTTP_201_CREATED)
    else:
        return Response({"message": "Duplicate code or invalid data"}, status=status.HTTP_400_BAD_REQUEST)


@api_view(["POST","GET","PUT","DELETE","PATCH","COPY","HEAD","OPTION","LINK","UNLINK","LOCK","UNLOCK","VIEW","PROFIND","PURGE"])
def product_list(request):
    if request.method != 'GET':
        return Response({"message":"A GET request expected"},status=status.HTTP_400_BAD_REQUEST)
    search =request.GET
    if search :
        selectedProducts = Product.objects.filter(name__contains=search['search'])
        jsonObject = ProductSerializer(selectedProducts, many=True)
        return Response({"products": jsonObject.data}, status=status.HTTP_200_OK)
    else:
        selectedProducts = Product.objects.all()
        jsonObject = ProductSerializer(selectedProducts, many=True)
        return Response({"products": jsonObject.data}, status=status.HTTP_200_OK)


@api_view(["POST","GET","PUT","DELETE","PATCH","COPY","HEAD","OPTION","LINK","UNLINK","LOCK","UNLOCK","VIEW","PROFIND","PURGE"])
def product_detail(request, pk):
    if request.method != 'GET':
        return Response({"message":"A GET request expected"},status=status.HTTP_400_BAD_REQUEST)
    try:
        jsonObject = ProductSerializer( Product.objects.get(pk=pk))
        return Response(jsonObject.data, status=status.HTTP_200_OK)
    except:
        return Response({"message": "product not found"}, status=status.HTTP_404_NOT_FOUND)

@api_view(["POST","GET","PUT","DELETE","PATCH","COPY","HEAD","OPTION","LINK","UNLINK","LOCK","UNLOCK","VIEW","PROFIND","PURGE"])
def editProductInventory(request,pk):
    if request.method != 'POST':
        return Response({"message": "A POST request expected"}, status=status.HTTP_400_BAD_REQUEST)
    try:
        case=Product.objects.get(pk=pk)
    except:
        return Response({"message": "product not found"}, status=status.HTTP_404_NOT_FOUND)
    try:
        val=int(request.data['amount'])
    except:
        return Response({"message": "bad request"}, status=status.HTTP_400_BAD_REQUEST)
    if val>0:
        case.increase_inventory(val)
    elif val<0:
        try:
            case.decrease_inventory(abs(val))
        except:
            return Response({"message": "Not enough inventory"}, status=status.HTTP_400_BAD_REQUEST)

    return Response(ProductSerializer(case).data, status=status.HTTP_200_OK)


#*********PHASE 4 VIEWS*************************************************************************
#*********PHASE 4 VIEWS*************************************************************************
#*********PHASE 4 VIEWS*************************************************************************
#*********PHASE 4 VIEWS*************************************************************************
#*********PHASE 4 VIEWS*************************************************************************
#*********PHASE 4 VIEWS*************************************************************************
#*********PHASE 4 VIEWS*************************************************************************




@api_view(["POST","GET","PUT","DELETE","PATCH","COPY","HEAD","OPTION","LINK","UNLINK","LOCK","UNLOCK","VIEW","PROFIND","PURGE"])
@authentication_classes([CsrfExemptSessionAuthentication])
def shoppingCart(request):
    if request.method != 'GET':
        return Response({"message": "A GET request expected"}, status=status.HTTP_400_BAD_REQUEST)
    if not request.user.is_authenticated:
        return Response({"message":"Please log in first."}, status=status.HTTP_403_FORBIDDEN)
    customer = request.user.customer
    try:
        order=customer.order_set.get(status=Order.STATUS_SHOPPING)
    except:
        order=Order.initiate(customer=customer)
    cart=order.orderrow_set.all()
    ser_cart=OrderRowSerializer(cart,many=True)
    data={"total price":order.total_price,
          "items":[{'code':x['product']['code'],
                    'name':x['product']['name'],
                    'price':x['product']['price'],
                    'amount':x['amount'] }
                   for x in ser_cart.data
                   ]
          }
    return Response(data, status=status.HTTP_200_OK)





@api_view(["POST","GET","PUT","DELETE","PATCH","COPY","HEAD","OPTION","LINK","UNLINK","LOCK","UNLOCK","VIEW","PROFIND","PURGE"])
@authentication_classes([CsrfExemptSessionAuthentication])
def add_items(request):
    if request.method != 'POST':
        return Response({"message": "A POST request expected"}, status=status.HTTP_400_BAD_REQUEST)
    if not request.user.is_authenticated:
        return Response({"message":"Please log in first."}, status=status.HTTP_403_FORBIDDEN)
    customer = request.user.customer
    try:
        Order.initiate(customer=customer)
    except:
        pass
    order=customer.order_set.get(status=Order.STATUS_SHOPPING)
    data=request.data
    result={"total price":order.total_price, "errors":[],"items":[]}
    for x in data:
        try:
            product=Product.objects.get(code=x['code'])
            try:
                order.add_product(product,x['amount'])
            except Exception as e:
                result['errors'].append(
                    {"code": x['code'], "message": e.__str__()})
        except:
            result['errors'].append({"code":x['code'],"message":"Product not found."})

    result['total price'] = order.total_price
    cart=order.orderrow_set.all()
    ser_cart=OrderRowSerializer(cart, many=True)
    result['items']=[{'code':x['product']['code'],
                    'name':x['product']['name'],
                    'price':x['product']['price'],
                    'amount':x['amount'] }
                   for x in ser_cart.data
                   ]
    if result['errors']==[]:
        result.pop('errors')
        stat=status.HTTP_200_OK
    else:
        stat=status.HTTP_400_BAD_REQUEST
    return Response(result,status=stat)




@api_view(["POST", "GET", "PUT", "DELETE", "PATCH", "COPY", "HEAD", "OPTION", "LINK", "UNLINK", "LOCK", "UNLOCK", "VIEW", "PROFIND", "PURGE"])
@authentication_classes([CsrfExemptSessionAuthentication])
def remove_items(request):
    if request.method != 'POST':
        return Response({"message": "A POST request expected."}, status=status.HTTP_400_BAD_REQUEST)
    if not request.user.is_authenticated:
        return Response({"message": "Please log in first."}, status=status.HTTP_403_FORBIDDEN)
    customer = request.user.customer
    try:
        order = customer.order_set.get(status=Order.STATUS_SHOPPING)
    except:
        return Response({"message":"No open order exists"}, status=status.HTTP_400_BAD_REQUEST)
    data=request.data
    result={"total price":0, "errors":[] , "items":[]}
    for x in data:
        try:
            product=Product.objects.get(code=x['code'])
            order.remove_product(product=product,amount=x.get('amount'))
        except Exception as e:
            result['errors'].append(  { "code":x['code'],
                                        "message":str(e)}  )
    orderows=order.orderrow_set.all()
    if orderows:
        ser_cart=OrderRowSerializer(orderows,many=True)
        result['total price']=order.total_price
        result['items']=[{'code':x['product']['code'],
                        'name':x['product']['name'],
                        'price':x['product']['price'],
                        'amount':x['amount'] }
                       for x in ser_cart.data
                       ]
    if result['errors']==[]:
        result.pop('errors')
        stat=status.HTTP_200_OK
    else:
        stat=status.HTTP_400_BAD_REQUEST
    return Response(result,status=stat)


@api_view(
    ["POST", "GET", "PUT", "DELETE", "PATCH", "COPY", "HEAD", "OPTION", "LINK", "UNLINK", "LOCK", "UNLOCK", "VIEW",
     "PROFIND", "PURGE"])
@authentication_classes([CsrfExemptSessionAuthentication])
def submit(request):
    if request.method != 'POST':
        return Response({"message": "A POST request expected."}, status=status.HTTP_400_BAD_REQUEST)
    if not request.user.is_authenticated:
        return Response({"message": "Please log in first."}, status=status.HTTP_403_FORBIDDEN)
    try:
        order = request.user.customer.order_set.get(status=Order.STATUS_SHOPPING)
    except:
        return Response({"message":"No open request exists."}, status=status.HTTP_400_BAD_REQUEST)
    try:

        order.submit()
        submittedCart = order.orderrow_set.all()
        ser_cart = OrderRowSerializer(submittedCart, many=True)
        data = {"id":order.id,
                "order_time":order.order_time,
                "status":order.status,
                "total price": order.total_price,
                "items": [  {'code': x['product']['code'],
                             'name': x['product']['name'],
                             'price': x['product']['price'],
                             'amount': x['amount']} for x in ser_cart.data]
                }
        return Response(data, status=status.HTTP_200_OK)
    except Exception as e:
        return Response(str(e), status=status.HTTP_400_BAD_REQUEST)



